import src.Match.*;
import java.util.Scanner;

public class Cricket {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Team-1 name: ");
            String team1Name = sc.nextLine();
            
            System.out.print("Enter Team-2 name: ");
            String team2Name = sc.nextLine();
            
            System.out.print("Enter number of overs: ");
            int overs = sc.nextInt();

            Main team1Match = new Main(team1Name, overs);
            Main team2Match = new Main(team2Name, overs);

            Team team1 = team1Match.playMatch();
            int team1Score = team1.getTeamScore();

            Team team2 = team2Match.playMatch();
            int team2Score = team2.getTeamScore();

            System.out.println("\n=== Match Result ===");
            System.out.println(team1Name + ": " + team1Score);
            System.out.println(team2Name + ": " + team2Score);

            if (team1Score > team2Score) {
                System.out.println(team1Name + " wins by " + (team1Score - team2Score) + " runs!");
            } 
            else if (team2Score > team1Score) {
                System.out.println(team2Name + " wins by " + (team2Score - team1Score) + " runs!");
            } 
            else {
                System.out.println("Match tied!");
            }

            System.out.println("\n=== " + team1Name + " Total Score ===");
            team1.displayTeamStats();

            System.out.println("\n=== " + team2Name + " Total Score ===");
            team2.displayTeamStats();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }
}