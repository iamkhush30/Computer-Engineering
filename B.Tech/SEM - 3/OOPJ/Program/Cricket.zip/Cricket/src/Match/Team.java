package src.Match;

import java.util.Scanner;

public class Team {
    private Player[] players;
    private int currentBatsmanIndex;
    private int totalScore;
    private int wicketsLost;
    private int ballsBowled;
    private int extras;
    private int wideBalls;
    private int noBalls;

    public Team(String[] playerNames) {
        players = new Player[playerNames.length];
        for (int i = 0; i < playerNames.length; i++) {
            players[i] = new Player(playerNames[i]);
        }
        currentBatsmanIndex = 0;
        totalScore = 0;
        wicketsLost = 0;
        ballsBowled = 0;
        extras = 0;
        wideBalls = 0;
        noBalls = 0;
    }

    public void playBall(int result) throws InvalidInputException {
        Scanner sc = new Scanner(System.in);
        switch (result) {
            case 1: // Wicket
                System.out.println(players[currentBatsmanIndex].getName() + " got out!");
                wicketsLost++;
                ballsBowled++;
                currentBatsmanIndex++;
                break;
            case 2: // Normal run
                System.out.print("Enter runs scored (0-6): ");
                int runs = sc.nextInt();
                players[currentBatsmanIndex].playBall(runs);
                totalScore += runs;
                ballsBowled++;
                System.out.println(runs + " runs scored.");
                break;
            case 3: // Wide ball
                wideBalls++;
                extras++;
                totalScore++;
                System.out.println("Wide ball! 1 extra run.");
                System.out.print("Enter additional runs scored off the wide (0-6): ");
                int wideRuns = sc.nextInt();
                if (wideRuns > 0) {
                    players[currentBatsmanIndex].playBall(wideRuns);
                    totalScore += wideRuns;
                    System.out.println(wideRuns + " additional runs scored off the wide ball.");
                }
                break;
            case 4: // No ball
                noBalls++;
                extras++;
                totalScore++;
                System.out.println("No ball! 1 extra run. Free hit awarded.");
                System.out.print("Enter runs scored off the no ball (0-6): ");
                int noBallRuns = sc.nextInt();
                if (noBallRuns > 0) {
                    players[currentBatsmanIndex].playBall(noBallRuns);
                    totalScore += noBallRuns;
                    System.out.println(noBallRuns + " runs scored off the no ball.");
                }
                break;
            default:
                throw new InvalidInputException("Invalid choice! Please enter 1, 2, 3, or 4.");
        }
    }

    public int getTeamScore(){
        return totalScore;
    }

    public void displayTeamStats() {
        System.out.println("Team Score: " + totalScore + "/" + wicketsLost);
        System.out.println("Extras: " + extras + " (Wide: " + wideBalls + ", No Ball: " + noBalls + ")");
        System.out.println("Total Balls Bowled: " + ballsBowled);
        System.out.println("\nPlayer Stats:");

        for (int i = 0; i <= currentBatsmanIndex && i < players.length; i++) {
            players[i].displayStats();
            System.out.println();
        }
    }

    public int getWicketsLost() {
        return wicketsLost;
    }

    public int getBallsBowled() {
        return ballsBowled;
    }
}