package src.Match;

class Player {
    private String name;
    private int runs;
    private int ballsFaced;
    private int fours;
    private int sixes;

    public Player(String name) {
        this.name = name;
        this.runs = 0;
        this.ballsFaced = 0;
        this.fours = 0;
        this.sixes = 0;
    }

    public void playBall(int result) throws InvalidInputException {
        if (result < 0 || result > 6) 
            throw new InvalidInputException("Invalid runs! Runs must be between 0 and 6.");
        
        else if (result == 4) 
            fours++;
        else if (result == 6) 
            sixes++;
        
        ballsFaced++;
        runs += result;
    }

    public void displayStats() {
        System.out.println();
        System.out.println("Player Name : " + name);
        System.out.println("Runs Scored : " + runs);
        System.out.println("Balls Faced : " + ballsFaced);
        System.out.println("No. of 4's  : " + fours);
        System.out.println("No. of 6's  : " + sixes);
        System.out.println();
    }

    public String getName() {
        return name;
    }
}