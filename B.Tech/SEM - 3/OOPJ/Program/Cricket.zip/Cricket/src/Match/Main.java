package src.Match;

import java.util.Scanner;

public class Main {
    final String teamName;
    static int over;

    public Main(String name, int over){
        this.teamName = name;
        this.over = over;
    }

    public Team playMatch() {
        Scanner sc = new Scanner(System.in);
        Team team = null;

        try {
            String[] playerNames = {"Player - A", "Player - B", "Player - C", "Player - D", "Player - E",
                                    "Player - F", "Player - G", "Player - H", "Player - I", "Player - J", "Player - K"};
            
            int totalBalls = over * 6;

            System.out.println("\n<===============" + teamName + " Batting==============>\n");

            team = new Team(playerNames);

            while (team.getBallsBowled() < totalBalls && team.getWicketsLost() < 10) {
                System.out.println("\nBall " + (team.getBallsBowled() + 1) + " of over " + ((team.getBallsBowled() / 6) + 1));
                System.out.println("1. Wicket");
                System.out.println("2. Run");
                System.out.println("3. Wide Ball");
                System.out.println("4. No Ball");
                System.out.print("Enter your choice: ");
                int result = sc.nextInt();
                switch (result) {
                    case 1,2,3,4:
                        team.playBall(result);
                        break;
                }
            }

        } catch (InvalidInputException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: Invalid input. Please try again.");
            e.printStackTrace();
        }
        return team;
    }
}